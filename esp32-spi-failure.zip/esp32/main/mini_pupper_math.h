/* Authors : 
 * - Hdumcke
 * - Pat92fr
 */

#ifndef _mini_pupper_math_H
#define _mini_pupper_math_H

#include <algorithm>
/* use min, max, clamp from C++ <algorithm>
s16 constrain(s16 value, s16 min, s16 max)
{
    if(value>max)
        return max;
    else if(value<min)
        return min;
    else
        return value;
}
*/

#endif // _mini_pupper_math_H
