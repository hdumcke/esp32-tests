#ifndef mini_pupper_cmd_h
#define mini_pupper_cmd_h

void register_mini_pupper_cmds(void);
void register_mini_pupper_extended_cmds(void);

#endif
